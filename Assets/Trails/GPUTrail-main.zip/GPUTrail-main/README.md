# GPUTrail
 
I haven't got around to documentation yet, but you can watch [this excellent tutorial by Le Lu](https://www.youtube.com/watch?v=0VsEfP4XFCM)

Any suggestions? Feel free to open an issue.

![heart](https://github.com/celyk/GPUTrail/assets/50609684/a190fee3-682b-42b9-9bef-cd49a5e3b99c)
